<?php
/**
 * Main Cron Job for Fetching Match Data
 * 
 * This script should be run via cPanel cron jobs:
 * - Every 3 minutes during match hours (14:00-22:00 UTC)
 * - Every 30 minutes for daily fixtures
 * - Every 2 hours for tomorrow's fixtures
 * 
 * Example cPanel cron job commands:
 * Every 3 minutes during match hours: php /path/to/cron/fetch-matches.php live
 * Every 30 minutes for today: php /path/to/cron/fetch-matches.php today  
 * Every 2 hours for tomorrow: php /path/to/cron/fetch-matches.php tomorrow
 */

// Prevent web access
if (isset($_SERVER['HTTP_HOST'])) {
    die('This script can only be run from command line.');
}

// Include configuration and classes
require_once __DIR__ . '/../config/api-config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../classes/Database.php';
require_once __DIR__ . '/../classes/MatchManager.php';

class MatchFetcher {
    private $db;
    private $matchManager;
    private $logFile;
    
    public function __construct() {
        $this->db = Database::getInstance();
        $this->matchManager = new MatchManager();
        $this->logFile = __DIR__ . '/../logs/cron.log';
        
        // Reset daily counters if needed
        $this->db->resetDailyCounters();
    }
    
    public function fetchMatches($type = 'today') {
        $startTime = microtime(true);
        $this->log("Starting fetch for type: $type");
        
        try {
            // Check if we need to update based on cache age
            if (!$this->shouldUpdate($type)) {
                $this->log("Cache is still fresh for $type, skipping update");
                return;
            }
            
            // Check API rate limit
            $requestsToday = $this->db->getApiRequestsToday();
            if ($requestsToday >= MAX_API_REQUESTS_PER_DAY) {
                $this->log("API rate limit reached: $requestsToday/" . MAX_API_REQUESTS_PER_DAY);
                return;
            }
            
            // Determine API endpoint
            $endpoint = $this->getAPIEndpoint($type);
            if (!$endpoint) {
                $this->log("Invalid type: $type");
                return;
            }
            
            // Fetch data from API-Sports
            $data = $this->fetchFromAPI($endpoint);
            if (!$data) {
                $this->log("Failed to fetch data from API");
                return;
            }
            
            // Process and save matches
            $savedCount = $this->processMatches($data['response'] ?? []);
            
            // Update cache metadata
            $this->matchManager->updateCacheMetadata($type, [
                'endpoint' => $endpoint,
                'matches_count' => $savedCount,
                'api_requests_today' => $this->db->getApiRequestsToday()
            ]);
            
            // Increment API request counter
            $this->db->incrementApiRequests($type);
            
            $duration = round((microtime(true) - $startTime) * 1000);
            $this->log("Successfully processed $savedCount matches for $type in {$duration}ms");
            
        } catch (Exception $e) {
            $this->log("Error fetching matches: " . $e->getMessage());
        }
    }
    
    private function shouldUpdate($type) {
        $cacheInfo = $this->matchManager->getCacheInfo($type);
        if (!$cacheInfo) {
            return true; // No cache exists
        }
        
        $ageMinutes = $cacheInfo['age_minutes'];
        
        switch ($type) {
            case 'live':
                return $ageMinutes >= CACHE_LIVE_MATCHES;
            case 'today':
                return $ageMinutes >= CACHE_TODAY_MATCHES;
            case 'tomorrow':
                return $ageMinutes >= CACHE_TOMORROW_MATCHES;
            default:
                return $ageMinutes >= 60; // Default 1 hour
        }
    }
    
    private function getAPIEndpoint($type) {
        switch ($type) {
            case 'live':
                return '/fixtures?live=all';
            case 'today':
                return '/fixtures?date=' . date('Y-m-d');
            case 'tomorrow':
                $tomorrow = date('Y-m-d', strtotime('+1 day'));
                return '/fixtures?date=' . $tomorrow;
            case 'leagues':
                return '/leagues';
            default:
                return null;
        }
    }
    
    private function fetchFromAPI($endpoint) {
        $url = API_SPORTS_BASE_URL . $endpoint;
        $this->log("Fetching from: $endpoint");
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTPHEADER => [
                API_SPORTS_HEADER . ': ' . API_SPORTS_KEY
            ],
            CURLOPT_USERAGENT => 'YallaFoot/1.0'
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            $this->log("cURL error: $error");
            return false;
        }
        
        if ($httpCode !== 200) {
            $this->log("HTTP error: $httpCode");
            return false;
        }
        
        $data = json_decode($response, true);
        if (!$data) {
            $this->log("Failed to decode JSON response");
            return false;
        }
        
        if (!empty($data['errors'])) {
            $this->log("API errors: " . implode(', ', $data['errors']));
            return false;
        }
        
        $this->log("API response: " . ($data['results'] ?? 0) . " results");
        return $data;
    }
    
    private function processMatches($matches) {
        $savedCount = 0;
        
        foreach ($matches as $matchData) {
            if ($this->matchManager->saveMatch($matchData)) {
                $savedCount++;
            }
        }
        
        return $savedCount;
    }
    
    private function log($message) {
        $timestamp = date('Y-m-d H:i:s');
        $logMessage = "[$timestamp] $message\n";
        
        echo $logMessage; // For cron job output
        
        if (ENABLE_LOGGING) {
            file_put_contents($this->logFile, $logMessage, FILE_APPEND | LOCK_EX);
        }
    }
}

// Main execution
if (isset($argv[1])) {
    $type = $argv[1];
    $fetcher = new MatchFetcher();
    $fetcher->fetchMatches($type);
} else {
    echo "Usage: php fetch-matches.php [live|today|tomorrow|leagues]\n";
    exit(1);
}
?>